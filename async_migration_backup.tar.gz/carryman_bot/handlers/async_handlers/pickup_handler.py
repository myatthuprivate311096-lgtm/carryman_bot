import os
import asyncio
import html
import pytz
import time
from datetime import datetime, timedelta
from telebot.async_telebot import AsyncTeleBot
from telebot import types, util
from logger import log
import db_manager
from modules import auditor

async def register_pickup_handlers(bot: AsyncTeleBot):
    """ Auto Pickup Module အတွက် Callback များကို Register လုပ်ပေးသည် (Async Version) """

    @bot.callback_query_handler(func=lambda call: call.data.startswith('done_'))
    async def handle_pickup_done_callback(call):
        try:
            from modules import auto_pickup
            parts = call.data.split('_')
            if len(parts) == 3:
                orig_msg_id = int(parts[1])
                chat_id = int(parts[2])
                
                # send_success_report is sync, wrap it
                await asyncio.to_thread(auto_pickup.send_success_report, bot, orig_msg_id, chat_id, handled_by=f"ဝန်ထမ်း ({call.from_user.first_name})")
                # update_central_pickup_alert is sync, wrap it
                await asyncio.to_thread(auto_pickup.update_central_pickup_alert, bot, orig_msg_id, chat_id, "✅ Success (ဝန်ထမ်းမှ အတည်ပြုပြီး)", show_done=False)
                await asyncio.to_thread(db_manager.resolve_message, orig_msg_id, chat_id, call.from_user.first_name, method='Manual', status='DONE')
            
            await bot.delete_message(call.message.chat.id, call.message.message_id)
            await bot.answer_callback_query(call.id, "✅ Pickup request marked as success.")
        except Exception as e:
            log.error(f"❌ Pickup Done Callback Error: {e}")
            try: await bot.answer_callback_query(call.id, "❌ Error deleting message")
            except: pass

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_dt_') or call.data.startswith('ap_vh_'))
    async def handle_auto_pickup_callback(call):
        is_staff = await asyncio.to_thread(db_manager.check_if_staff, call.from_user.id)
        if is_staff:
            await bot.answer_callback_query(call.id, "⚠️ Staff Account မှဖြေပေးလို့မရပါ", show_alert=True)
            return
        try:
            from modules import auto_pickup
            parts = call.data.split('_')
            action = parts[1]
            orig_msg_id = int(parts[2])
            date_type = parts[3]
            vehicle = parts[4] if parts[4] != "none" else None
            chat_id = call.message.chat.id

            if action == "dt" or not vehicle:
                if not vehicle:
                    # ask_vehicle is sync, wrap it
                    await asyncio.to_thread(auto_pickup.ask_vehicle, bot, call.message, date_type, orig_msg_id, show_cancel=False)
                    return
            
            # ask_remark is sync, wrap it
            await asyncio.to_thread(auto_pickup.ask_remark, bot, chat_id, date_type, vehicle, orig_msg_id, show_cancel=False)
            await bot.delete_message(chat_id, call.message.message_id)

        except Exception as e:
            log.error(f"❌ Auto Pickup Callback Error: {e}")
            try: await bot.answer_callback_query(call.id, "❌ Error occurred", show_alert=True)
            except: pass
        finally:
            try: await bot.answer_callback_query(call.id)
            except: pass

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_st_'))
    async def handle_staff_pickup_decision(call):
        try:
            from modules import auto_pickup
            parts = call.data.split('_')
            orig_msg_id = int(parts[2])
            chat_id = int(parts[3])
            date_type = parts[4]
            vehicle = parts[5] if parts[5] != "none" else "none"

            markup = types.InlineKeyboardMarkup(row_width=1)
            markup.add(
                types.InlineKeyboardButton("OK", callback_data=f"ap_pconf_{orig_msg_id}_{date_type}"),
                types.InlineKeyboardButton("💬 Admin နှင့်ပြောမည်", callback_data=f"ap_admin_0_{orig_msg_id}"),
                types.InlineKeyboardButton("❌ Pick Up မဟုတ်ပါ", callback_data=f"ap_cancel_{orig_msg_id}")
            )

            if date_type == "today":
                text = "ဒီနေ့အတွက် Pick up တင်ပေးလို့ရပါတယ်ရှင်။ တင်ပေးရမလားရှင့်"
                status_admin = "📅 Today (Waiting OS)"
                log_msg = "✅ **Today** အတွက် OS ထံ အတည်ပြုချက် တောင်းခံထားပါသည် အစ်ကို။"
            else:
                text = "ဒီနေ့ rider လေးကဝေးလမ်းကြောင်းလေးကျော်သွားပြီမို့လို့ မနက်ဖြန်လေးကောက်ပေးလို့ရမလားရှင့်"
                status_admin = "📅 Tomorrow (Waiting OS)"
                log_msg = "✅ **Tomorrow** အတွက် OS ထံ အတည်ပြုချက် တောင်းခံထားပါသည် အစ်ကို။"

            old_msgs = await asyncio.to_thread(db_manager.get_pickup_intermediate_msgs, chat_id, orig_msg_id)
            for m_id in old_msgs:
                try: await bot.delete_message(chat_id, m_id)
                except: pass
            await asyncio.to_thread(db_manager.delete_pickup_intermediate_msgs, chat_id, orig_msg_id)

            sent_msg = await bot.send_message(chat_id, text, reply_to_message_id=orig_msg_id, reply_markup=markup)
            await asyncio.to_thread(db_manager.add_pickup_intermediate_msg, chat_id, orig_msg_id, sent_msg.message_id)
            
            await bot.edit_message_text(log_msg, call.message.chat.id, call.message.message_id)
            await asyncio.to_thread(auto_pickup.update_central_pickup_alert, bot, orig_msg_id, chat_id, status_admin)

        except Exception as e:
            log.error(f"❌ Staff Pickup Decision Error: {e}")
            try: await bot.answer_callback_query(call.id, "❌ Error occurred")
            except: pass
        finally:
            try: await bot.answer_callback_query(call.id)
            except: pass

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_pconf_'))
    async def handle_pickup_confirm_initial_callback(call):
        try:
            from modules import auto_pickup
            parts = call.data.split('_')
            orig_msg_id = int(parts[2])
            date_type = parts[3]
            chat_id = call.message.chat.id
            
            tz = pytz.timezone('Asia/Yangon')
            msg_ctx = await asyncio.to_thread(db_manager.get_message_context, orig_msg_id, chat_id)
            msg_ts = msg_ctx[4] if msg_ctx else datetime.now(tz).timestamp()
            msg_dt = datetime.fromtimestamp(msg_ts, tz)
            target_date_str = (msg_dt if date_type == "today" else msg_dt + timedelta(days=1)).strftime("%d-%m-%Y")
            
            def get_data():
                with db_manager.connection_scope() as conn:
                    msg_data = conn.execute("SELECT text, summary FROM message_logs WHERE msg_id = ? AND chat_id = ?", (orig_msg_id, chat_id)).fetchone()
                    _, _, shop_name = db_manager.get_topic_context(chat_id, 1)
                return msg_data, shop_name

            data, shop_name = await asyncio.to_thread(get_data)
            
            if data:
                orig_text, clean_remark = data
                await asyncio.to_thread(auto_pickup.send_admin_pickup_alert, bot, chat_id, orig_msg_id, shop_name, target_date_str, None, clean_remark, orig_text)
            
            await asyncio.to_thread(auto_pickup.show_interactive_setup, bot, chat_id, orig_msg_id, date_type, edit_msg_id=call.message.message_id)
            await bot.answer_callback_query(call.id)
        except Exception as e:
            log.error(f"❌ Pickup Confirm Initial Callback Error: {e}")

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_ivh_'))
    async def handle_interactive_vehicle_callback(call):
        try:
            from modules import auto_pickup
            parts = call.data.split('_')
            orig_msg_id = int(parts[2])
            date_type = parts[3]
            vehicle = parts[4]
            chat_id = call.message.chat.id

            tz = pytz.timezone('Asia/Yangon')
            msg_ctx = await asyncio.to_thread(db_manager.get_message_context, orig_msg_id, chat_id)
            msg_ts = msg_ctx[4] if msg_ctx else datetime.now(tz).timestamp()
            msg_dt = datetime.fromtimestamp(msg_ts, tz)
            target_date = (msg_dt if date_type == "today" else msg_dt + timedelta(days=1)).strftime("%d-%m-%Y")
            
            def update_db():
                _, _, shop_name = db_manager.get_topic_context(chat_id, 1)
                db_manager.upsert_pickup_queue(chat_id, orig_msg_id, target_date, shop_name, None, vehicle, status='WAITING_SETUP')
            
            await asyncio.to_thread(update_db)
            await asyncio.to_thread(auto_pickup.show_interactive_setup, bot, chat_id, orig_msg_id, date_type, vehicle=vehicle, edit_msg_id=call.message.message_id)
            await bot.answer_callback_query(call.id, f"✅ {vehicle} ကို ရွေးချယ်လိုက်ပါသည်")
        except Exception as e:
            log.error(f"❌ Interactive Vehicle Callback Error: {e}")

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_irm_'))
    async def handle_interactive_remark_callback(call):
        try:
            parts = call.data.split('_')
            orig_msg_id = int(parts[2])
            date_type = parts[3]
            
            msg = await bot.send_message(call.message.chat.id, "📝 ထည့်ချင်တဲ့ **မှတ်ချက်** ကို ရိုက်ထည့်ပေးပါခင်ဗျာ။", reply_markup=types.ForceReply())
            await asyncio.to_thread(db_manager.add_pickup_intermediate_msg, call.message.chat.id, orig_msg_id, msg.message_id)
            # register_next_step_handler is tricky with async, but telebot supports it
            bot.register_next_step_handler(msg, save_manual_remark_interactive, bot, orig_msg_id, date_type, call.message.message_id, msg.message_id)
            await bot.answer_callback_query(call.id)
        except Exception as e:
            log.error(f"❌ Interactive Remark Callback Error: {e}")

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_isb_'))
    async def handle_interactive_submit_callback(call):
        try:
            parts = call.data.split('_')
            orig_msg_id = int(parts[2])
            date_type = parts[3]
            chat_id = call.message.chat.id

            order = await asyncio.to_thread(db_manager.get_pickup_order_by_msg, orig_msg_id, chat_id)
            vehicle = order[6] if order else None
            remark = order[5] if order else None

            if not vehicle or vehicle == "none":
                await bot.answer_callback_query(call.id, "⚠️ စက်ဘီး/ကား ကိုတော့မဖြစ်မနေရွေးပေးပါနော်", show_alert=True)
                return

            tz = pytz.timezone('Asia/Yangon')
            msg_ctx = await asyncio.to_thread(db_manager.get_message_context, orig_msg_id, chat_id)
            msg_ts = msg_ctx[4] if msg_ctx else datetime.now(tz).timestamp()
            msg_dt = datetime.fromtimestamp(msg_ts, tz)
            target_date = (msg_dt if date_type == "today" else msg_dt + timedelta(days=1)).strftime("%d-%m-%Y")
            
            def finalize():
                with db_manager.connection_scope() as conn:
                    msg_data = conn.execute("SELECT summary FROM message_logs WHERE msg_id = ? AND chat_id = ?", (orig_msg_id, chat_id)).fetchone()
                ai_summary = msg_data[0] if msg_data else None
                final_remark = remark if remark else (ai_summary if ai_summary else "-")
                _, _, shop_name = db_manager.get_topic_context(chat_id, 1)
                queue_id = db_manager.upsert_pickup_queue(chat_id, orig_msg_id, target_date, shop_name, final_remark, vehicle, status='PENDING')
                db_manager.update_pickup_field(queue_id, 'shop_msg_id', call.message.message_id)
                return queue_id, shop_name, final_remark

            queue_id, shop_name, final_remark = await asyncio.to_thread(finalize)

            status_text = (
                f"⏳ **Auto Pickup အချက်အလက်များ**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"📅 ရက်စွဲ: {target_date}\n"
                f"🏪 ဆိုင်: <b>{util.escape(shop_name)}</b>\n"
                f"🚲 ယာဉ်: <b>{vehicle}</b>\n"
                f"📝 မှတ်ချက်: {final_remark}\n"
                f"📊 Status: <b>⏳ Pending</b>\n"
                f"━━━━━━━━━━━━━━━━━━"
            )
            await bot.edit_message_text(status_text, chat_id, call.message.message_id, parse_mode="HTML")
            
            from modules import auto_pickup
            await asyncio.to_thread(auto_pickup.update_central_pickup_alert, bot, orig_msg_id, chat_id, "⏳ Pending", queue_id=queue_id)
            await bot.answer_callback_query(call.id, "✅ Pickup တင်ရန် အတည်ပြုလိုက်ပါပြီ")
        except Exception as e:
            log.error(f"❌ Interactive Submit Callback Error: {e}")

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_cancel_'))
    async def handle_pickup_cancel_callback(call):
        is_staff = await asyncio.to_thread(db_manager.check_if_staff, call.from_user.id)
        if is_staff:
            await bot.answer_callback_query(call.id, "⚠️ Staff Account မှဖြေပေးလို့မရပါ", show_alert=True)
            return
        try:
            from modules import auto_pickup
            orig_msg_id = int(call.data.split('_')[2])
            chat_id = call.message.chat.id
            
            tracking = await asyncio.to_thread(db_manager.get_alert_tracking, orig_msg_id, chat_id)
            if tracking:
                alert_msg_id = tracking[0]
                central_chat = int(os.getenv('CENTRAL_GROUP_ID', -1003601049225))
                try: await bot.delete_message(central_chat, alert_msg_id)
                except: pass
                await asyncio.to_thread(db_manager.delete_alert_tracking, orig_msg_id, chat_id)

            await asyncio.to_thread(db_manager.update_message_status, orig_msg_id, chat_id, 'PENDING')
            await bot.delete_message(chat_id, call.message.message_id)
            await asyncio.to_thread(auto_pickup.cleanup_pickup_intermediate_msgs, bot, chat_id, orig_msg_id)
            await bot.answer_callback_query(call.id, "✅ Pickup မဟုတ်ကြောင်း မှတ်သားပြီး ပုံမှန်စာအဖြစ် ပြန်ပြောင်းလိုက်ပါပြီ။")
        except Exception as e:
            log.error(f"❌ Pickup Cancel Callback Error: {e}")
        finally:
            try: await bot.answer_callback_query(call.id)
            except: pass

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_rm_'))
    async def handle_remark_selection(call):
        is_staff = await asyncio.to_thread(db_manager.check_if_staff, call.from_user.id)
        if is_staff:
            await bot.answer_callback_query(call.id, "⚠️ Staff Account မှဖြေပေးလို့မရပါ", show_alert=True)
            return
        try:
            from modules import auto_pickup
            parts = call.data.split('_')
            orig_msg_id = int(parts[2])
            date_type = parts[3]
            vehicle = parts[4]
            action = parts[5]
            chat_id = call.message.chat.id

            if action == "write":
                msg = await bot.send_message(chat_id, "📝 ထည့်ချင်တဲ့ **မှတ်ချက်** ကို ရိုက်ထည့်ပေးပါခင်ဗျာ။", reply_markup=types.ForceReply())
                await asyncio.to_thread(db_manager.add_pickup_intermediate_msg, chat_id, orig_msg_id, msg.message_id)
                bot.register_next_step_handler(msg, save_manual_remark, bot, orig_msg_id, date_type, vehicle)
                await bot.delete_message(chat_id, call.message.message_id)
            else:
                await bot.edit_message_text("🙏 ဟုတ်ကဲ့ပါခင်ဗျာ။", chat_id, call.message.message_id)
                await finalize_pickup_queue(bot, chat_id, orig_msg_id, date_type, vehicle, None)

        except Exception as e:
            log.error(f"❌ Remark Selection Error: {e}")
        finally:
            try: await bot.answer_callback_query(call.id)
            except: pass

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_fix_'))
    async def handle_fix_mapping_callback(call):
        try:
            user_level = await asyncio.to_thread(db_manager.get_user_level, call.from_user.id, call.message.chat.id)
            if user_level < 3:
                await bot.answer_callback_query(call.id, "⚠️ ဤလုပ်ဆောင်ချက်ကို Admin များသာ အသုံးပြုနိုင်ပါသည်။", show_alert=True)
                return

            chat_id = int(call.data.split('_')[2])
            from modules import auto_pickup
            
            chat_title = call.message.chat.title or ""
            if '🤝' in chat_title:
                raw_shop_name = chat_title.split('🤝')[0].strip()
            else:
                def get_shop():
                    with db_manager.connection_scope() as conn:
                        shop_data = conn.execute("SELECT shop_name FROM os_groups WHERE chat_id = ?", (chat_id,)).fetchone()
                    return db_manager.clean_shop_name(shop_data[0]) if shop_data else "Unknown"
                raw_shop_name = await asyncio.to_thread(get_shop)

            await bot.answer_callback_query(call.id, "⏳ Website မှ ဆိုင်စာရင်းများကို Sync လုပ်နေပါသည်...")
            # sync_shops_from_website is sync, wrap it
            await asyncio.to_thread(auto_pickup.sync_shops_from_website)

            suggestions = await asyncio.to_thread(db_manager.get_website_suggestions, raw_shop_name[:5])
            shop_name_esc = util.escape(raw_shop_name)

            markup = types.InlineKeyboardMarkup(row_width=1)
            for s in suggestions:
                s_esc = util.escape(s)
                import hashlib
                temp_id = hashlib.md5(s.encode()).hexdigest()[:8]
                await asyncio.to_thread(db_manager.save_temp_data, f"shop_{temp_id}", s)
                markup.add(types.InlineKeyboardButton(f"✅ {s_esc}", callback_data=f"ap_set_{chat_id}_{temp_id}"))
            
            markup.add(types.InlineKeyboardButton("⌨️ Manual Type (ကိုယ်တိုင်ရိုက်မည်)", callback_data=f"ap_manual_{chat_id}"))

            await bot.edit_message_text(
                f"🔍 **Shop Mapping Fix**\n━━━━━━━━━━━━━━━━━━\n"
                f"🏪 Telegram: <b>{shop_name_esc}</b>\n\n"
                f"အောက်ပါ Website ဆိုင်နာမည်များထဲမှ မှန်ကန်တာကို ရွေးပေးပါ-",
                call.message.chat.id, call.message.message_id,
                reply_markup=markup, parse_mode="HTML"
            )
        except Exception as e:
            log.error(f"❌ Fix Mapping Callback Error: {e}")
            try: await bot.answer_callback_query(call.id, "❌ အမှားတစ်ခု ဖြစ်သွားပါသည်။", show_alert=True)
            except: pass

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_set_'))
    async def handle_set_mapping_callback(call):
        try:
            parts = call.data.split('_')
            chat_id = int(parts[2])
            temp_id = parts[3]
            
            website_name = await asyncio.to_thread(db_manager.get_temp_data, f"shop_{temp_id}")
            if not website_name:
                await bot.answer_callback_query(call.id, "⚠️ Session expired. Please try 'Fix Shop Mapping' again.", show_alert=True)
                return

            await asyncio.to_thread(db_manager.set_shop_mapping, chat_id, website_name)
            await asyncio.to_thread(db_manager.retry_failed_pickups, chat_id)
            await bot.edit_message_text(f"✅ **Mapping သိမ်းဆည်းပြီးပါပြီ!**\n\n`{website_name}` အဖြစ် သတ်မှတ်လိုက်ပါသည်။ ကျရှုံးခဲ့သော Pickup များကို ပြန်လည်တင်ပေးနေပါပြီ။", call.message.chat.id, call.message.message_id)
        except Exception as e:
            log.error(f"❌ Set Mapping Callback Error: {e}")
        finally:
            try: await bot.answer_callback_query(call.id)
            except: pass

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_manual_'))
    async def handle_manual_mapping_callback(call):
        try:
            chat_id = int(call.data.split('_')[2])
            msg = await bot.send_message(call.message.chat.id, "📝 Website မှာရှိတဲ့ **ဆိုင်နာမည် အတိအကျ** ကို ရိုက်ထည့်ပေးပါခင်ဗျာ။", reply_markup=types.ForceReply())
            bot.register_next_step_handler(msg, save_manual_mapping, bot, chat_id)
        except Exception as e:
            log.error(f"❌ Manual Mapping Callback Error: {e}")
        finally:
            try: await bot.answer_callback_query(call.id)
            except: pass

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_conf_'))
    async def handle_pickup_confirm_callback(call):
        is_staff = await asyncio.to_thread(db_manager.check_if_staff, call.from_user.id)
        if is_staff:
            await bot.answer_callback_query(call.id, "⚠️ Staff Account မှဖြေပေးလို့မရပါ", show_alert=True)
            return
        try:
            queue_id = int(call.data.split('_')[2])
            order = await asyncio.to_thread(db_manager.get_pickup_order, queue_id)
            if not order:
                await bot.answer_callback_query(call.id, "❌ Order not found")
                return

            chat_id = call.message.chat.id
            orig_msg_id = order[2]
            target_date = order[3]
            shop_name = order[4]
            remark = order[5]
            vehicle = order[6]

            status_text = (
                f"✅ **အတည်ပြုပြီးပါပြီ!**\n\n"
                f"🏪 ဆိုင်: <b>{util.escape(shop_name)}</b>\n"
                f"📅 ရက်စွဲ: <b>{target_date}</b>\n"
                f"🚲 ယာဉ်: <b>{vehicle}</b>\n"
                f"📝 မှတ်ချက်: {remark if remark else '-'}\n"
                f"📊 Status: <b>⏳ Pending</b>\n\n"
                f"Pick up လေးတင်ပေးထားပါတယ်နော်"
            )

            await bot.edit_message_text(status_text, chat_id, call.message.message_id, parse_mode="HTML")
            await asyncio.to_thread(db_manager.confirm_pickup_order, queue_id, shop_msg_id=call.message.message_id)

            from modules import auto_pickup
            msg_ids = await asyncio.to_thread(db_manager.get_pickup_intermediate_msgs, chat_id, orig_msg_id)
            for mid in msg_ids:
                if mid != call.message.message_id:
                    try: await bot.delete_message(chat_id, mid)
                    except: pass
            await asyncio.to_thread(db_manager.delete_pickup_intermediate_msgs, chat_id, orig_msg_id)
            await asyncio.to_thread(auto_pickup.update_central_pickup_alert, bot, orig_msg_id, chat_id, "⏳ Pending", queue_id=queue_id)
                
        except Exception as e:
            log.error(f"❌ Pickup Confirm Callback Error: {e}")
        finally:
            try: await bot.answer_callback_query(call.id)
            except: pass

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_edit_'))
    async def handle_pickup_edit_callback(call):
        is_staff = await asyncio.to_thread(db_manager.check_if_staff, call.from_user.id)
        if is_staff:
            await bot.answer_callback_query(call.id, "⚠️ Staff Account မှဖြေပေးလို့မရပါ", show_alert=True)
            return
        try:
            queue_id = int(call.data.split('_')[2])
            pickup = await asyncio.to_thread(db_manager.get_pickup_order, queue_id)
            
            show_date_edit = True
            if pickup and len(pickup) > 8:
                created_at = pickup[8]
                if created_at:
                    tz = pytz.timezone('Asia/Yangon')
                    dt = datetime.fromtimestamp(created_at, tz)
                    if dt.hour >= 11: show_date_edit = False

            markup = types.InlineKeyboardMarkup()
            row1 = []
            if show_date_edit:
                row1.append(types.InlineKeyboardButton("📅 ရက်စွဲပြင်မည်", callback_data=f"ap_ed_date_{queue_id}"))
            row1.append(types.InlineKeyboardButton("🚲/🚗 ယာဉ်အမျိုးအစား", callback_data=f"ap_ed_v_{queue_id}"))
            markup.row(*row1)
            markup.row(types.InlineKeyboardButton("📝 မှတ်ချက်ပြင်မည်", callback_data=f"ap_ed_rem_{queue_id}"))
            markup.row(types.InlineKeyboardButton("🔙 နောက်သို့", callback_data=f"ap_ed_back_{queue_id}"))

            await bot.edit_message_text(
                "🛠 **ဘယ်အချက်အလက်ကို ပြင်ချင်ပါသလဲ?**\n\nပြင်ဆင်လိုသည့် ခလုတ်ကို နှိပ်ပေးပါခင်ဗျာ။",
                call.message.chat.id, call.message.message_id, reply_markup=markup
            )
        except Exception as e:
            log.error(f"❌ Pickup Edit Callback Error: {e}")
        finally:
            try: await bot.answer_callback_query(call.id)
            except: pass

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_upd_'))
    async def handle_update_field_callback(call):
        is_staff = await asyncio.to_thread(db_manager.check_if_staff, call.from_user.id)
        if is_staff:
            await bot.answer_callback_query(call.id, "⚠️ Staff Account မှဖြေပေးလို့မရပါ", show_alert=True)
            return
        try:
            parts = call.data.split('_')
            field_type = parts[2]
            queue_id = int(parts[3])
            value = parts[4]
            
            if field_type == "date":
                tz = pytz.timezone('Asia/Yangon')
                order = await asyncio.to_thread(db_manager.get_pickup_order, queue_id)
                orig_msg_id = order[2] if order else 0
                chat_id = order[1] if order else 0
                msg_ctx = await asyncio.to_thread(db_manager.get_message_context, orig_msg_id, chat_id)
                msg_ts = msg_ctx[4] if msg_ctx else datetime.now(tz).timestamp()
                msg_dt = datetime.fromtimestamp(msg_ts, tz)
                value = (msg_dt if value == "today" else msg_dt + timedelta(days=1)).strftime("%d-%m-%Y")
                await asyncio.to_thread(db_manager.update_pickup_field, queue_id, 'target_date', value)
            elif field_type == "v":
                await asyncio.to_thread(db_manager.update_pickup_field, queue_id, 'vehicle', value)
                
            await bot.answer_callback_query(call.id, "✅ ပြင်ဆင်ပြီးပါပြီ")
            await show_pickup_reconfirmation(bot, call.message.chat.id, queue_id, call.message.message_id)
        except Exception as e:
            log.error(f"❌ Update Field Callback Error: {e}")
        finally:
            try: await bot.answer_callback_query(call.id)
            except: pass

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_admin_'))
    async def handle_pickup_admin_callback(call):
        is_staff = await asyncio.to_thread(db_manager.check_if_staff, call.from_user.id)
        if is_staff:
            await bot.answer_callback_query(call.id, "⚠️ Staff Account မှဖြေပေးလို့မရပါ", show_alert=True)
            return
        try:
            from modules import auto_pickup
            parts = call.data.split('_')
            queue_id = int(parts[2])
            orig_msg_id = int(parts[3])
            chat_id = call.message.chat.id
            
            await asyncio.to_thread(db_manager.delete_pickup_order, queue_id)
            await asyncio.to_thread(db_manager.set_manual_alert, orig_msg_id, chat_id)
            
            def get_admin_data():
                with db_manager.connection_scope() as conn:
                    msg_data = conn.execute("SELECT text, timestamp, media_id FROM message_logs WHERE msg_id = ? AND chat_id = ?", (orig_msg_id, chat_id)).fetchone()
                    _, _, shop_name = db_manager.get_topic_context(chat_id, 1)
                return msg_data, shop_name

            msg_data, shop_name = await asyncio.to_thread(get_admin_data)
            
            if msg_data:
                text, ts, media_id = msg_data
                await asyncio.to_thread(auditor.send_new_alert, chat_id, 1, orig_msg_id, text, "Rider requested Admin support", shop_name, ts, media_id=media_id, title="🚨 **Urgent Alert (Rider Request)**", force=True, target_topic_override=1)
                
                tracking = await asyncio.to_thread(db_manager.get_alert_tracking, orig_msg_id, chat_id)
                if tracking:
                    try: await bot.delete_message(tracking[1], tracking[0])
                    except: pass
                    await asyncio.to_thread(db_manager.delete_alert_tracking, orig_msg_id, chat_id)
    
                await asyncio.to_thread(auto_pickup.cleanup_pickup_intermediate_msgs, bot, chat_id, orig_msg_id)
                await bot.send_message(chat_id, "တာဝန်ရှိသူထံ အကြောင်းကြားပြီးပါပြီ။ အမြန်ဆုံး ပြန်လည်အကြောင်းပြန်ပေးပါ့မယ်နော်", reply_to_message_id=orig_msg_id)
        except Exception as e:
            log.error(f"❌ Pickup Admin Callback Error: {e}")
        finally:
            try: await bot.answer_callback_query(call.id)
            except: pass

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_wrong_'))
    async def handle_wrong_pickup_callback(call):
        try:
            parts = call.data.split('_')
            if parts[2] == "back": return
            
            if parts[2] == "staff":
                orig_msg_id, chat_id, vehicle = int(parts[3]), int(parts[4]), parts[5]
                back_callback = f"ap_wrong_back_staff_{orig_msg_id}_{chat_id}_{vehicle}"
            else:
                orig_msg_id, chat_id = int(parts[2]), int(parts[3])
                back_callback = f"ap_wrong_back_{orig_msg_id}_{chat_id}"

            markup = types.InlineKeyboardMarkup(row_width=1)
            markup.add(
                types.InlineKeyboardButton("📋 စာရင်းပေးရုံသာ (List only)", callback_data=f"ap_fb_{orig_msg_id}_{chat_id}_LIST"),
                types.InlineKeyboardButton("💬 စကားပြောရုံသာ (Casual)", callback_data=f"ap_fb_{orig_msg_id}_{chat_id}_CASUAL"),
                types.InlineKeyboardButton("❓ စုံစမ်းမေးမြန်းခြင်း (Inquiry)", callback_data=f"ap_fb_{orig_msg_id}_{chat_id}_INQUIRY"),
                types.InlineKeyboardButton("🚫 အခြား (Other)", callback_data=f"ap_fb_{orig_msg_id}_{chat_id}_OTHER"),
                types.InlineKeyboardButton("🔙 Back", callback_data=back_callback)
            )
            await bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=markup)
            await bot.answer_callback_query(call.id, "AI ကို သင်ယူစေရန် အကြောင်းရင်း ရွေးပေးပါ အစ်ကို")
        except Exception as e:
            log.error(f"❌ Wrong Pickup Callback Error: {e}")

    @bot.callback_query_handler(func=lambda call: call.data.startswith('ap_fb_'))
    async def handle_pickup_feedback_callback(call):
        try:
            from modules import auto_pickup
            parts = call.data.split('_')
            orig_msg_id, chat_id, category = int(parts[2]), int(parts[3]), parts[4]

            def get_fb_data():
                with db_manager.connection_scope() as conn:
                    return conn.execute("SELECT text, topic_id FROM message_logs WHERE msg_id = ? AND chat_id = ?", (orig_msg_id, chat_id)).fetchone()
            
            msg_data = await asyncio.to_thread(get_fb_data)
            if msg_data:
                orig_text, topic_id = msg_data
                await asyncio.to_thread(db_manager.save_feedback, orig_msg_id, chat_id, topic_id, category, orig_text, call.from_user.id)
                await asyncio.to_thread(db_manager.update_message_status, orig_msg_id, chat_id, 'CANCELLED')
                await asyncio.to_thread(auto_pickup.cleanup_pickup_intermediate_msgs, bot, chat_id, orig_msg_id)
                try: await bot.delete_message(call.message.chat.id, call.message.message_id)
                except: pass
                await bot.answer_callback_query(call.id, f"✅ AI သင်ယူပြီးပါပြီ ({category})။ ကျေးဇူးပါ အစ်ကို။")
            else:
                await bot.answer_callback_query(call.id, "⚠️ မူရင်းစာသား ရှာမတွေ့တော့ပါ")
        except Exception as e:
            log.error(f"❌ Pickup Feedback Callback Error: {e}")

# --- Helper Functions (Async Wrappers) ---

async def save_manual_remark_interactive(message, bot, orig_msg_id, date_type, edit_msg_id, prompt_msg_id=None):
    try:
        from modules import auto_pickup
        remark = message.text.strip()
        chat_id = message.chat.id
        try: await bot.delete_message(chat_id, message.message_id)
        except: pass
        if prompt_msg_id:
            try: await bot.delete_message(chat_id, prompt_msg_id)
            except: pass
        
        tz = pytz.timezone('Asia/Yangon')
        msg_ctx = await asyncio.to_thread(db_manager.get_message_context, orig_msg_id, chat_id)
        msg_ts = msg_ctx[4] if msg_ctx else datetime.now(tz).timestamp()
        msg_dt = datetime.fromtimestamp(msg_ts, tz)
        target_date = (msg_dt if date_type == "today" else msg_dt + timedelta(days=1)).strftime("%d-%m-%Y")
        
        def update():
            _, _, shop_name = db_manager.get_topic_context(chat_id, 1)
            order = db_manager.get_pickup_order_by_msg(orig_msg_id, chat_id)
            vehicle = order[6] if order else None
            db_manager.upsert_pickup_queue(chat_id, orig_msg_id, target_date, shop_name, remark, vehicle, status='WAITING_SETUP')
            return vehicle, remark
        
        vehicle, remark = await asyncio.to_thread(update)
        await asyncio.to_thread(auto_pickup.show_interactive_setup, bot, chat_id, orig_msg_id, date_type, vehicle=vehicle, remark=remark, edit_msg_id=edit_msg_id)
    except Exception as e:
        log.error(f"❌ Save Manual Remark Interactive Error: {e}")

async def save_manual_remark(message, bot, orig_msg_id, date_type, vehicle):
    try:
        remark = message.text.strip()
        chat_id = message.chat.id
        await asyncio.to_thread(db_manager.add_pickup_intermediate_msg, chat_id, orig_msg_id, message.message_id)
        if not remark:
            sent_msg = await bot.reply_to(message, "⚠️ မှတ်ချက် အလွတ်ဖြစ်နေလို့ မူရင်းစာသားအတိုင်းပဲ တင်ပေးလိုက်ပါမယ်။")
            await asyncio.to_thread(db_manager.add_pickup_intermediate_msg, chat_id, orig_msg_id, sent_msg.message_id)
            remark = None
        await finalize_pickup_queue(bot, chat_id, orig_msg_id, date_type, vehicle, remark)
    except Exception as e:
        log.error(f"❌ Save Manual Remark Error: {e}")

async def finalize_pickup_queue(bot, chat_id, orig_msg_id, date_type, vehicle, manual_remark):
    try:
        tz = pytz.timezone('Asia/Yangon')
        msg_ctx = await asyncio.to_thread(db_manager.get_message_context, orig_msg_id, chat_id)
        msg_ts = msg_ctx[4] if msg_ctx else datetime.now(tz).timestamp()
        msg_dt = datetime.fromtimestamp(msg_ts, tz)
        target_date = (msg_dt if date_type == "today" else msg_dt + timedelta(days=1)).strftime("%d-%m-%Y")
        
        def get_final_data():
            with db_manager.connection_scope() as conn:
                msg_data = conn.execute("SELECT text, summary FROM message_logs WHERE msg_id = ? AND chat_id = ?", (orig_msg_id, chat_id)).fetchone()
            ai_summary = msg_data[1] if msg_data and msg_data[1] else None
            final_remark = manual_remark if manual_remark else (ai_summary if ai_summary else "-")
            _, _, shop_name = db_manager.get_topic_context(chat_id, 1)
            return final_remark, shop_name

        final_remark, shop_name = await asyncio.to_thread(get_final_data)
        
        if not vehicle or vehicle == "none":
            from modules import auto_pickup
            await asyncio.to_thread(auto_pickup.ask_vehicle, bot, types.Message(message_id=orig_msg_id, from_user=None, date=None, chat=types.Chat(id=chat_id, type='group'), text=""), date_type, orig_msg_id)
            return

        queue_id = await asyncio.to_thread(db_manager.upsert_pickup_queue, chat_id, orig_msg_id, target_date, shop_name, final_remark, vehicle, status='WAITING_CONFIRM')
        
        confirm_text = (
            f"⏳ **Auto Pickup အချက်အလက်များ**\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"📅 ရက်စွဲ: {target_date}\n"
            f"🏪 ဆိုင်: {shop_name}\n"
            f"🚲 ယာဉ်: {vehicle}\n"
            f"📝 မှတ်ချက်: {final_remark}\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"အထက်ပါအချက်များကို အတည်ပြုပေးပါဦးနော်။"
        )

        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("✅ Right (အတည်ပြုသည်)", callback_data=f"ap_conf_{queue_id}"),
            types.InlineKeyboardButton("✏️ ပြင်ဦးမည်", callback_data=f"ap_edit_{queue_id}"),
            types.InlineKeyboardButton("👨‍💼 Admin နှင့်ပြောမည်", callback_data=f"ap_admin_{queue_id}_{orig_msg_id}")
        )
        
        sent_msg = await bot.send_message(chat_id, confirm_text, reply_to_message_id=orig_msg_id, reply_markup=markup)
        await asyncio.to_thread(db_manager.add_pickup_intermediate_msg, chat_id, orig_msg_id, sent_msg.message_id)
        
        from modules import auto_pickup
        await asyncio.to_thread(auto_pickup.update_central_pickup_alert, bot, orig_msg_id, chat_id, "⏳ Waiting Confirmation (Rider)", queue_id=queue_id)
    except Exception as e:
        log.error(f"❌ Finalize Pickup Queue Error: {e}")

async def show_pickup_reconfirmation(bot, chat_id, queue_id, message_id=None):
    try:
        order = await asyncio.to_thread(db_manager.get_pickup_order, queue_id)
        if not order: return
        _, _, orig_msg_id, target_date, shop_name, remark, vehicle, status, _ = order
        confirm_text = (
            f"⏳ **Auto Pickup အချက်အလက်များ (ပြင်ဆင်ပြီး)**\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"📅 ရက်စွဲ: {target_date}\n"
            f"🏪 ဆိုင်: {shop_name}\n"
            f"🚲 ယာဉ်: {vehicle}\n"
            f"📝 မှတ်ချက်: {remark}\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"အချက်အလက်များ မှန်ကန်ပါက အတည်ပြုပေးပါဦးနော်။"
        )
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("✅ Right (အတည်ပြုသည်)", callback_data=f"ap_conf_{queue_id}"),
            types.InlineKeyboardButton("✏️ ပြင်ဦးမည်", callback_data=f"ap_edit_{queue_id}"),
            types.InlineKeyboardButton("👨‍💼 Admin နှင့်ပြောမည်", callback_data=f"ap_admin_{queue_id}_{orig_msg_id}")
        )
        if message_id:
            await bot.edit_message_text(confirm_text, chat_id, message_id, reply_markup=markup)
        else:
            sent_msg = await bot.send_message(chat_id, confirm_text, reply_markup=markup)
            await asyncio.to_thread(db_manager.add_pickup_intermediate_msg, chat_id, orig_msg_id, sent_msg.message_id)
    except Exception as e:
        log.error(f"❌ Show Pickup Reconfirmation Error: {e}")

async def save_manual_mapping(message, bot, chat_id):
    try:
        website_name = message.text.strip()
        if not website_name:
            await bot.reply_to(message, "❌ နာမည် အလွတ်ဖြစ်နေလို့ မသိမ်းပေးနိုင်ပါဘူး။")
            return
        await asyncio.to_thread(db_manager.set_shop_mapping, chat_id, website_name)
        await asyncio.to_thread(db_manager.retry_failed_pickups, chat_id)
        await bot.reply_to(message, f"✅ **Mapping သိမ်းဆည်းပြီးပါပြီ!**\n\nနောက်ပိုင်း ဒီ Group ကတက်လာတဲ့ Pick up တွေကို Website ထဲက `{website_name}` နာမည်နဲ့ တင်ပေးသွားပါမယ်။ ကျရှုံးခဲ့သော Pickup များကိုလည်း ပြလည်တင်ပေးနေပါပြီ။")
    except Exception as e:
        log.error(f"❌ Save Manual Mapping Error: {e}")

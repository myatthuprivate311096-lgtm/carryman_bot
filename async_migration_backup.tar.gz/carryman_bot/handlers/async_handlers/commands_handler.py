import os
import asyncio
import subprocess
import psutil
import html
import json
from telebot.async_telebot import AsyncTeleBot
from telebot import types
from logger import log
import db_manager
import gsheet_sync
from modules import auditor, group_creator

# Environment Variable
MANAGER_ID = int(os.getenv('MANAGER_ID', 0))
MANAGER_IDS = [int(i.strip()) for i in os.getenv('MANAGER_IDS', str(MANAGER_ID)).split(',')]

def is_manager(user_id):
    return user_id in MANAGER_IDS

BRANCHES = ["Yangon", "Insein", "Htauk Kyant", "Mandalay"]
DEPARTMENTS = [
    "OS Service", "Rider Service", "Rider Finance", "OS Finance", 
    "Accountant", "Data Entry", "Marketing", "HR", "Admin", 
    "Rider", "Agent", "Other"
]

staff_reg_data = {}
register_group_data = {}

async def register_handlers(bot: AsyncTeleBot):
    """ Bot Command အားလုံးကို ဤနေရာတွင် စုစည်းမှတ်ပုံတင်ပေးသည် (Async Version) """
    
    @bot.message_handler(commands=['gsupdate'])
    async def handle_gs_update(message):
        user_level = await asyncio.to_thread(db_manager.get_user_level, message.from_user.id, message.chat.id)
        if user_level == 4:
            msg = await bot.reply_to(message, "⏳ **Google Sheet မှ ဒေတာများကို ရယူနေပါသည်...**")
            sheet_url = os.getenv('GSHEET_URL')
            if not sheet_url:
                await bot.edit_message_text("❌ `.env` ထဲမှာ `GSHEET_URL` ထည့်သွင်းထားခြင်း မရှိသေးပါ အစ်ကို။", msg.chat.id, msg.message_id)
                return

            syncer = gsheet_sync.GSheetSync()
            # sync_knowledge is sync, wrap it
            success, result_msg = await asyncio.to_thread(syncer.sync_knowledge, sheet_url)
            
            if success:
                await bot.edit_message_text(f"✅ **Sync Success!**\n\n{result_msg}", msg.chat.id, msg.message_id)
            else:
                await bot.edit_message_text(f"❌ **Sync Failed!**\n\n{result_msg}", msg.chat.id, msg.message_id)
        else:
            await bot.reply_to(message, "⚠️ ဤ Command ကို Manager သာ အသုံးပြုခွင့်ရှိပါသည်။")

    @bot.message_handler(commands=['aion', 'aioff', 'ai_on', 'ai_off'])
    async def handle_ai_global_toggle(message):
        user_level = await asyncio.to_thread(db_manager.get_user_level, message.from_user.id, message.chat.id)
        if user_level >= 3:
            status = 'ON' if 'on' in message.text.lower() else 'OFF'
            await asyncio.to_thread(db_manager.set_ai_global_status, status)
            await bot.reply_to(message, f'✅ **AI Auto-Reply has been turned {status}**', parse_mode="Markdown")
        else:
            await bot.reply_to(message, "🚫 **Access Denied**")

    @bot.message_handler(commands=['status'])
    async def handle_status(message):
        user_level = await asyncio.to_thread(db_manager.get_user_level, message.from_user.id, message.chat.id)
        if user_level >= 3:
            ai_global = await asyncio.to_thread(db_manager.get_ai_global_status)
            pickup_global = await asyncio.to_thread(db_manager.get_auto_pickup_global_status)
            alert_global = await asyncio.to_thread(db_manager.get_alert_system_global_status)
            
            cpu_usage = psutil.cpu_percent()
            ram_usage = psutil.virtual_memory().percent
            
            status_text = (
                "🤖 **CarryMan Async Receiver Diagnostics**\n"
                "━━━━━━━━━━━━━━━━━━\n"
                f"🧠 AI Answer: **{ai_global}**\n"
                f"📦 Auto Pickup: **{pickup_global}**\n"
                f"🚨 Alert System: **{alert_global}**\n\n"
                f"🖥 CPU: {cpu_usage}%\n"
                f"💾 RAM: {ram_usage}%\n"
                "━━━━━━━━━━━━━━━━━━"
            )
            await bot.reply_to(message, status_text, parse_mode="Markdown")

    @bot.message_handler(commands=['alert'])
    async def handle_manual_alert(message):
        if not message.reply_to_message:
            await bot.reply_to(message, "⚠️ Alert ထုတ်လိုသော စာကို Reply ဆွဲပြီးမှ `/alert` ဟု ရိုက်ပေးပါဗျာ။")
            return

        orig_msg = message.reply_to_message
        chat_id = message.chat.id
        topic_id = orig_msg.message_thread_id if (getattr(orig_msg, 'is_topic_message', False) and orig_msg.message_thread_id) else 1
        
        is_os = await asyncio.to_thread(db_manager.check_if_os_group, chat_id)
        if not is_os:
            await bot.reply_to(message, "⚠️ ဤ Command ကို OS Group များအတွင်းသာ အသုံးပြုနိုင်ပါသည်။")
            return

        await asyncio.to_thread(db_manager.set_manual_alert, orig_msg.message_id, chat_id)
        _, _, shop_name = await asyncio.to_thread(db_manager.get_topic_context, chat_id, topic_id)
        
        text = orig_msg.text or orig_msg.caption
        media_id = None
        if not text:
            if orig_msg.photo: text = "🖼️ Photo"; media_id = orig_msg.photo[-1].file_id
            elif orig_msg.voice: text = "🎙️ Voice Message"; media_id = orig_msg.voice.file_id
            else: text = "📦 Media Content"

        await asyncio.to_thread(
            auditor.send_new_alert,
            chat_id, topic_id, orig_msg.message_id,
            text, "Manual Alert", shop_name, orig_msg.date,
            media_id=media_id, title="🚨 **Urgent Alert (Manual)**"
        )
        
        try: await bot.delete_message(chat_id, message.message_id)
        except: pass

    @bot.message_handler(commands=['stafflist'])
    async def handle_staff_list(message):
        is_staff = await asyncio.to_thread(db_manager.check_if_staff, message.from_user.id)
        if is_manager(message.from_user.id) or is_staff:
            staffs = await asyncio.to_thread(db_manager.get_all_staff)
            if staffs:
                msg = "👥 **ဝန်ထမ်းစာရင်း:**\n"
                for u, n, b, d in staffs:
                    msg += f"• {n} (`{u}`) | {b} | {d}\n"
            else:
                msg = "⚠️ ဝန်ထမ်းစာရင်း မရှိသေးပါ။"
            await bot.reply_to(message, msg, parse_mode="Markdown")

    @bot.message_handler(commands=['pkreset'])
    async def handle_pk_reset(message):
        user_level = await asyncio.to_thread(db_manager.get_user_level, message.from_user.id, message.chat.id)
        if user_level == 4:
            try:
                q_count, l_count = await asyncio.to_thread(db_manager.reset_today_pickups, message.chat.id)
                response = f"♻️ **Today's Pickup Reset Success!**\nDeleted: {q_count}, Reset: {l_count}"
                await bot.reply_to(message, response, parse_mode="Markdown")
            except Exception as e:
                await bot.reply_to(message, f"❌ Error: {e}")
        else:
            await bot.reply_to(message, "🚫 **Access Denied**")

# Version: 6.0 (Async Receiver Process)
import os
import asyncio
from telebot.async_telebot import AsyncTeleBot
from dotenv import load_dotenv
from logger import log
import db_manager
from handlers.async_handlers import (
    message_handler as async_message_handler,
    alert_handler as async_alert_handler,
    pickup_handler as async_pickup_handler,
    commands_handler as async_commands_handler
)
import async_main_router

# 💡 Absolute Path Fix for .env
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, '.env'))

BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
MANAGER_ID = int(os.getenv('MANAGER_ID'))
MANAGER_IDS = [int(i.strip()) for i in os.getenv('MANAGER_IDS', str(MANAGER_ID)).split(',')]

def is_manager(user_id):
    return user_id in MANAGER_IDS

# Initialize Async Bot
bot = AsyncTeleBot(BOT_TOKEN)

async def start_bot():
    log.info("🚀 Async CarryMan Receiver is starting...")
    
    # Initialize DB (Sync call is fine here at startup)
    db_manager.init_db()

    # Register Handlers
    await async_commands_handler.register_handlers(bot)
    await async_alert_handler.register_alert_handlers(bot, is_manager)
    await async_pickup_handler.register_pickup_handlers(bot)
    await async_message_handler.register_message_handlers(bot, is_manager)

    @bot.message_handler(commands=['ai'])
    async def handle_ai_command(message):
        """ /ai command handler for Smart AI Support (Async) """
        await async_main_router.handle_ai_query(bot, message)

    while True:
        try:
            log.info("📡 Async Polling started...")
            await bot.infinity_polling(
                timeout=60, 
                long_polling_timeout=60, 
                skip_pending=False, 
                allowed_updates=['message', 'callback_query', 'edited_message']
            )
        except Exception as e:
            log.error(f"⚠️ Async Bot Polling Error: {e}")
            if "409" in str(e):
                log.warning("🔄 Conflict detected, waiting 20 seconds...")
                await asyncio.sleep(20)
            else:
                await asyncio.sleep(5)

if __name__ == "__main__":
    try:
        asyncio.run(start_bot())
    except KeyboardInterrupt:
        log.info("🛑 Async Bot stopped by user.")

import os
import json
import importlib
import asyncio
import db_manager
from dotenv import load_dotenv
from logger import log
import ai_utils

# 💡 Absolute Path Fix
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, '.env'))

SANDBOX_CHAT_ID = -1003539520778

def is_ai_office_hours():
    return True

async def handle_ai_query(bot, message, is_automatic=False):
    """
    Smart AI Support Logic (Async Version)
    """
    try:
        user_id = message.from_user.id
        chat_id = message.chat.id
        is_private = chat_id > 0
        is_sandbox = (chat_id == SANDBOX_CHAT_ID)

        if not is_private and not is_sandbox and is_automatic:
            log.info(f"🔇 AI Auto-Answer is disabled in Group Chat {chat_id} for automatic replies.")
            return

        user_level = await asyncio.to_thread(db_manager.get_user_level, user_id, chat_id)

        if is_private:
            _, human_needed = await asyncio.to_thread(db_manager.get_user_state, user_id)
            if human_needed:
                log.info(f"🔇 AI Muted for user {user_id}")
                return

        query = message.text.replace('/ai', '').strip() if not is_automatic else (message.text or message.caption or '')
        if not query and message.reply_to_message:
            query = message.reply_to_message.text or message.reply_to_message.caption
            
        if not query:
            await bot.reply_to(message, "💡 **ဘယ်လိုကူညီပေးရမလဲခင်ဗျာ?**\n\nမေးခွန်းကို တွဲရိုက်ပါ (သို့) မေးလိုသောစာကို Reply ပြန်ပြီး `/ai` လို့ ရိုက်ပါ။")
            return

        log.info(f"🤖 AI Query from {user_id}: {query[:50]}...")

        is_staff = user_level >= 3
        scope_check_prompt = ""
        if is_private and not is_staff:
            scope_check_prompt = "Scope Check: 'Determine if the user query is related to CarryMan Logistics services. If OUT OF SCOPE, output ONLY 'OUT_OF_SCOPE'."

        rag_instructions = ai_utils.get_rag_instructions(user_level)
        base_company_info = "[Base Company Info]: Office Address: သင်္ဃန်းကျွန်းမြို့နယ်၊ ရန်ကုန်မြို့။ Contact: 09789102234"
        core_policies = await asyncio.to_thread(db_manager.get_core_policies)

        ai_prompt = f"""
        Strict Persona: OS Admin.
        {rag_instructions}
        {scope_check_prompt}
        {base_company_info}
        {core_policies}
        User Query: "{query}"
        """
        
        tools = ai_utils.get_ai_tools(user_level)
        
        # AI Call (Wrapped in thread if not already async)
        response = await asyncio.to_thread(ai_utils.get_ai_completion, ai_prompt, timeout=30.0, tools=tools, user_level=user_level)
        
        if not response:
            await bot.reply_to(message, "⚠️ တောင်းပန်ပါတယ်ခင်ဗျာ။ အဖြေရှာနေစဉ် အမှားတစ်ခု ဖြစ်သွားလို့ပါ။")
            return

        answer = response

        if is_private and not is_staff and answer and "OUT_OF_SCOPE" in answer:
            count = await asyncio.to_thread(db_manager.increment_out_of_scope, user_id)
            if count < 3:
                await bot.reply_to(message, "တောင်းပန်ပါတယ်ခင်ဗျာ။ ကျွန်တော်က CarryMan Logistics နှင့် သက်ဆိုင်သော ဝန်ဆောင်မှုများကိုသာ ဖြေကြားပေးနိုင်ပါတယ်။")
                return
            else:
                await bot.reply_to(message, "admin ဆီကိုအကြောင်းကြားပေးထားတာမို့ ရုံးချိန်အတွင်းအမြန်ဆုံးဆက်သွယ်ပေးပါလိမ့်မယ်နော်")
                await asyncio.to_thread(db_manager.set_human_intervention, user_id, 1)
                return

        full_response = f"🤖 **CarryMan AI Agent**\n\n{answer}"
        if len(full_response) > 4000:
            parts = [full_response[i:i+4000] for i in range(0, len(full_response), 4000)]
            for idx, part in enumerate(parts):
                if idx == 0: await bot.reply_to(message, part)
                else: await bot.send_message(message.chat.id, part)
        else:
            await bot.reply_to(message, full_response)
            
        await asyncio.to_thread(db_manager.update_message_status, message.message_id, chat_id, 'HANDLED_BY_AI')

    except Exception as e:
        log.error(f"❌ Async AI Query Error: {e}")

async def route_message(bot, message):
    """
    AI မှ Message ကို ဖတ်ပြီး သက်ဆိုင်ရာ Module ဆီသို့ လမ်းကြောင်းပြောင်းပေးခြင်း (Async Version)
    """
    try:
        chat_id = message.chat.id
        user_id = message.from_user.id
        user_level = await asyncio.to_thread(db_manager.get_user_level, user_id, chat_id)
        is_staff = user_level >= 3
        is_private = chat_id > 0

        if not is_private and is_staff:
            return

        text = message.text or message.caption
        if not text: return

        global_ai = await asyncio.to_thread(db_manager.get_setting, 'global_ai_answer', 'ON')
        
        if text.strip().startswith('/ai'):
            if global_ai == 'ON' or chat_id == SANDBOX_CHAT_ID:
                await handle_ai_query(bot, message, is_automatic=False)
            return

        # Intent Detection
        prompt = f"Analyze intent: auto_pickup, check_order, auditor, or none. Message: {text}"
        intent = await asyncio.to_thread(ai_utils.get_ai_completion, prompt, timeout=30.0)
        if not intent: return
        intent = intent.strip().lower()

        if intent == "none": return

        if not is_private and chat_id != SANDBOX_CHAT_ID:
            if intent not in ["auto_pickup", "auditor"]: return

        if intent == "auto_pickup":
            if is_private or is_staff: return
        elif intent == "auditor":
            if is_private and not is_staff: return
            global_alert = await asyncio.to_thread(db_manager.get_setting, 'global_alert_system', 'ON')
            if not is_private and global_alert != 'ON' and chat_id != SANDBOX_CHAT_ID: return

        # Dynamic Loader
        if intent == 'auditor' and is_private and is_staff:
            await handle_ai_query(bot, message, is_automatic=True)
            return

        available_modules = ["auto_pickup", "check_order", "auditor"]
        if intent in available_modules:
            try:
                module = importlib.import_module(f"modules.{intent}")
                if hasattr(module, 'handle'):
                    # Check if handle is async
                    if asyncio.iscoroutinefunction(module.handle):
                        await module.handle(bot, message)
                    else:
                        await asyncio.to_thread(module.handle, bot, message)
            except Exception as me:
                log.error(f"❌ Async Router Module Error ({intent}): {me}")

    except Exception as e:
        log.error(f"❌ Async Router Error: {e}")

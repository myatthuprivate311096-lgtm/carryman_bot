import asyncio
import os
import sys
from telebot.async_telebot import AsyncTeleBot
from telebot import types

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from handlers.async_handlers import message_handler as async_message_handler
import async_main_router

async def test_async_flow():
    print("🧪 Testing Async Receiver Flow...")
    
    # Mock Bot
    class MockBot:
        def __init__(self):
            self.message_handlers = []
        
        def message_handler(self, **kwargs):
            def decorator(f):
                self.message_handlers.append(f)
                return f
            return decorator
        
        async def reply_to(self, message, text, **kwargs):
            print(f"🤖 Bot Reply: {text}")
            return types.Message(1, None, None, None, None, None, "")

        async def send_message(self, chat_id, text, **kwargs):
            print(f"🤖 Bot Send: {text}")
            return types.Message(1, None, None, None, None, None, "")

        async def get_chat_member(self, chat_id, user_id):
            class Member:
                status = 'member'
            return Member()

    mock_bot = MockBot()
    
    def is_manager(uid): return False

    print("📦 Registering handlers...")
    await async_message_handler.register_message_handlers(mock_bot, is_manager)
    
    # Simulate a message
    mock_user = types.User(12345, False, "TestUser")
    mock_chat = types.Chat(-100123456, "group", title="Test Shop 🤝 CarryMan")
    mock_message = types.Message(999, mock_user, 1600000000, mock_chat, "text", {"text": "Hello Bot"}, "")
    mock_message.is_topic_message = False
    
    print(f"📩 Simulating message: '{mock_message.text}'")
    
    # In a real bot, telebot calls the handler. Here we call it manually.
    handler = mock_bot.message_handlers[0]
    
    # We need to mock async_main_router.route_message to avoid real AI calls during test
    original_route = async_main_router.route_message
    async def mock_route(bot, msg):
        print("🧠 Mock Router: Routing message...")
    async_main_router.route_message = mock_route
    
    try:
        await handler(mock_message)
        print("✅ Async Handler executed successfully.")
    except Exception as e:
        print(f"❌ Async Handler failed: {e}")
    finally:
        async_main_router.route_message = original_route

if __name__ == "__main__":
    asyncio.run(test_async_flow())
